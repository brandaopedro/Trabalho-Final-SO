package simulador.mensagens;

public class MensagemRequest implements Mensagem {
    private int pid;

    public MensagemRequest(int pid) {
        this.pid = pid;
    }

    public int getPid() {
        return pid;
    }

    @Override
    public String toString() {
        return "" + pid;
    }
}
