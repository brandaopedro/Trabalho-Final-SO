package simulador.mensagens;

import java.io.Serializable;

public interface Mensagem extends Serializable {
}
