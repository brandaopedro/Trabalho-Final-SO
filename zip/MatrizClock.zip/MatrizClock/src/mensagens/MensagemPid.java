package simulador.mensagens;

public class MensagemPid implements Mensagem {
    private int pid;

    public MensagemPid(int pid) {
        this.pid = pid;
    }

     public int getPid() {
        return pid;
    }
}
