package simulador;


import simulador.mensagens.MensagemRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BaldoniRaynal {

    Map<Integer, IProcesso> processos;
    int localPid;
    EscutarLog escutarLog;
    List<Integer> pendentes;
    boolean querCS;
    int totalOkEsperados;
    List<Replicacao> replicas;
    private int p, p1;
    private static int cont = 1;

    public BaldoniRaynal(int localPid, Map<Integer, IProcesso> processos, List<Replicacao> replicas, int quantidadeMaquinas) {
        this.replicas = replicas;
        this.processos = processos;
        this.localPid = localPid;
        this.pendentes = new ArrayList<>();
        querCS = false;
        totalOkEsperados = 0;


    }

    private IProcesso getProcessoLocal(){
        return processos.get(localPid);
    }

    public void setEscutarLog(EscutarLog escutarLog) {
        this.escutarLog = escutarLog;
    }

    public void broadcast(){
        IProcesso processoLocal = getProcessoLocal();
        MensagemRequest mensagemRequest = new MensagemRequest(processoLocal.getPid());
        p = localPid - 30000;
        escutarLog.publicarInfo(replicas.get(p).imprimir_matriz());
        escutarLog.publicarLog("Local Information: \n" + replicas.get(p).imprimir_matriz());
        replicas.get(p).updatePiggyback();
        escutarLog.publicarLog("Piggyback: \n" + replicas.get(p).imprimir_piggyback(replicas.get(p).getVc()));
        replicas.get(p).initializeMessage(p,replicas.get(p).getVc(), cont);
        replicas.get(p).updateClock();
        escutarLog.publicarInfo(replicas.get(p).imprimir_matriz());
        escutarLog.publicarLog("Local Information: \n" + replicas.get(p).imprimir_matriz());
        escutarLog.atualizaBuffer(replicas.get(p).imprimir_buffer());
        cont++;

        for (Map.Entry<Integer, IProcesso> entry : processos.entrySet()) {
            IProcesso processo = entry.getValue();
            if (processo.getPid() != processoLocal.getPid()) {
                processo.enviarMensagem(mensagemRequest);
            }
        }
    }

    public void receive(MensagemRequest mensagem){
        p = localPid - 30000;
        p1 = mensagem.getPid()- 30000;
        escutarLog.publicarInfo(replicas.get(p).imprimir_matriz());
        escutarLog.publicarLog("Local Information: \n" + replicas.get(p).imprimir_matriz());
        replicas.get(p).initializeMessage(p1, replicas.get(p1).getVc(), cont-1);
        replicas.get(p).updateArray(p1, replicas.get(p1).getVc());
        escutarLog.publicarLog("Local Information: \n" + replicas.get(p).imprimir_matriz());
        replicas.get(p).updateBuffer();
        escutarLog.atualizaBuffer(replicas.get(p).imprimir_buffer());
        escutarLog.publicarInfo(replicas.get(p).imprimir_matriz());
    }



}
