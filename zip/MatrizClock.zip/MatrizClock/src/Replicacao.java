package simulador;

import java.util.ArrayList;

public class Replicacao {

    private int mc[][];
    private ArrayList<Mensagem> buffer;
    private int identifier;
    private int vc[];
    private int quantidade;
    private static String impMatriz, impVetor, impBuffer;
    EscutarLog escutarLog;


    public Replicacao(int identifier, int quantidade) {
        this.identifier = identifier;
        this.quantidade = quantidade;
        mc = new int[quantidade][quantidade];
        vc = new int[quantidade];
        buffer = new ArrayList<Mensagem>();
        fillArray();
        vectorFill();
    }

    private void fillArray() {
        for (int i = 0; i < quantidade; i++) {
            for (int j = 0; j < quantidade; j++) {
                mc[i][j] = 0;
            }
        }
        mc[identifier][identifier] = 1;
    }

    private void vectorFill() {
        for (int i = 0; i < quantidade; i++) {
            vc[i] = mc[identifier][i];
        }
    }

    public void initializeMessage(int nProcesso, int[] vc, int cont) {
        buffer.add(new Mensagem(nProcesso, vc, cont));
    }

    public void updateClock() {
        mc[this.identifier][this.identifier] += 1;
    }

    public int[] getVc() {
        return this.vc;
    }

    public void updateArray(int nProcesso, int[] piggyBack) {
        for (int i = 0; i < quantidade; i++) {
            this.mc[nProcesso][i] = piggyBack[i];
        }
        if (this.identifier != nProcesso) {
            this.mc[this.identifier][nProcesso]++;
        }

    }

    public void updatePiggyback(){
        for (int i = 0; i < quantidade; i++) {
            this.vc[i] = mc[identifier][i];
        }
    }

    public void updateBuffer() {
        if (buffer.size() > 0) {
            for (int i = 0; i < buffer.size(); i++) {
                if (buffer.get(i).getMessageValue() <= min(buffer.get(i).getSender())) {
                    buffer.remove(i);
                    i--;
                }
            }
        }


    }

    private int min(int sender) {
        int x = mc[0][sender];
        for (int j = 0; j < mc.length; j++) {
            if (x > mc[j][sender]) {
                x = mc[j][sender];
            }
        }
        return x;
    }

    public String imprimir_buffer() {
        impBuffer = "";
        for (int i = 0; i < buffer.size(); i++) {
            impBuffer = impBuffer + " " + buffer.get(i).getNome() + "\n";
        }
        return impBuffer;
    }

    public String imprimir_piggyback(int[] vet) {
        impVetor = "";
        for (int i = 0; i < mc.length; i++) {
            impVetor += toString().valueOf(vet[i]);
            if (i < this.quantidade-1)
                impVetor += " - ";
        }
        return impVetor;
    }

    public String imprimir_matriz() {
        impMatriz = "";
        for (int i = 0; i < mc.length; i++) {
            for (int j = 0; j < mc.length; j++) {
                impMatriz += toString().valueOf(mc[i][j]);
                if (j >= 0 && j < this.quantidade-1)
                    impMatriz += " - ";
            }
            if (i < this.quantidade-1)
                impMatriz += "\n";
        }
        return impMatriz;

    }

}



