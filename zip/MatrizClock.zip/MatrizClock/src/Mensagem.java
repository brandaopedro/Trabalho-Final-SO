package simulador;

public class Mensagem {
    private String nome;
    private int vc[];
    private int sender;
    private int cont;

    public Mensagem(int sender, int vc[], int cont){
        this.sender = sender;
        this.vc = vc;
        this.cont = cont;
        assingName();
    }

    private void assingName(){
        this.nome = "M"+ this.cont;
    }

    public String getNome() {
        return nome;
    }

    public int getSender() {
        return sender;
    }

    public int getMessageValue(){
        return vc[sender];
    }

}
