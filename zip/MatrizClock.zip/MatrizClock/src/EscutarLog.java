package simulador;



public interface EscutarLog {

    void publicarLog(String message);

    void publicarInfo(String message);

    void atualizaBuffer(String message);
}
