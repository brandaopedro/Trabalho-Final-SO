package simulador;

import simulador.mensagens.Mensagem;

public class ProcessoLocal implements IProcesso {

    private int pid;
    private String buffer;
    private EscutarLog escutarLog;

    public ProcessoLocal(int pid, EscutarLog escutarLog) {
        this.pid = pid;
        this.buffer = "";
        this.escutarLog =escutarLog;
    }

    @Override
    public void enviarMensagem(Mensagem mensagem) {

    }

    public void setBuffer(String buffer) {
        this.buffer = buffer;
        escutarLog.atualizaBuffer(buffer);
    }

    @Override
    public int getPid() {
        return pid;
    }



    private int max(int x, int y){
        return x > y ? x : y;
    }
}
