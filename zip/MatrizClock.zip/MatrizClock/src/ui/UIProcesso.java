package simulador.ui;

import simulador.EscutarLog;
import simulador.MaquinaVirtual;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UIProcesso extends JDialog {
    private JPanel contentPane;
    private JButton btnRequest;
    private JTextArea textArea1;
    private JLabel lblStatus;
    private JTextArea txtBuffer;
    private JTextPane txtLocalInfo;

    private MaquinaVirtual maquinaVirtual;

    public UIProcesso(MaquinaVirtual maquinaVirtual) {
        this.maquinaVirtual = maquinaVirtual;

        setContentPane(contentPane);
        getRootPane().setDefaultButton(btnRequest);
        setTitle("Processo: " + maquinaVirtual.getPid());


        btnRequest.setEnabled(true);
        txtBuffer.setText("");

        maquinaVirtual.setEscutarLog(new EscutarLog() {
            @Override
            public void publicarLog(String mensagem) {
                textArea1.setText(mensagem+"\n----------------------------------\n"+textArea1.getText());
            }

            @Override
            public void publicarInfo(String message) {

                txtLocalInfo.setText(message);
            }


            @Override
            public void atualizaBuffer(String buffer) {
                txtBuffer.setText(buffer);
            }

        });

        btnRequest.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        maquinaVirtual.getBaldoniRaynal().broadcast();
                    }
                }).start();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onOK() {
        // add your code here
        dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
