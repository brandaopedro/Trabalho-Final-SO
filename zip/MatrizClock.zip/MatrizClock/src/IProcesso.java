package simulador;

import simulador.mensagens.Mensagem;

public interface IProcesso {

    void enviarMensagem(Mensagem mensagem);
    int getPid();
}
