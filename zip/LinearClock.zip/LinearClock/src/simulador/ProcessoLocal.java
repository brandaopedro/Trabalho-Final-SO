package simulador;

import simulador.mensagens.Mensagem;

public class ProcessoLocal implements IProcesso {

    private int pid;
    private int clock;
    private EscutarLog escutarLog;

    public ProcessoLocal(int pid, EscutarLog escutarLog) {
        this.pid = pid;
        this.clock = 0;
        this.escutarLog =escutarLog;
    }

    @Override
    public void enviarMensagem(Mensagem mensagem) {

    }

    public void setClock(int clock) {
        this.clock = clock;
        escutarLog.atualizaClock(clock);
    }

    @Override
    public int getPid() {
        return pid;
    }

    @Override
    public int getProximoTimestamp() {
        setClock(clock+1);
        return clock;
    }

    @Override
    public int getTimestamp() {
        return clock;
    }

    public void updateClock(int timestamp){
        setClock(max(clock, timestamp));

    }

    private int max(int x, int y){
        return x > y ? x : y;
    }
}
