package simulador.mensagens;

public class MensagemOk implements Mensagem {
    int pid;
    int timestamp;

    public int getPid() {
        return pid;
    }

    public int getTimestamp() {
        return timestamp;
    }

    public MensagemOk(int pid, int timestamp) {
        this.pid = pid;
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "MensagemOk{" +
                "pid=" + pid +
                ", timestamp=" + timestamp +
                '}';
    }
}
