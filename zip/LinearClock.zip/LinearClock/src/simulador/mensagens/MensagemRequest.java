package simulador.mensagens;

public class MensagemRequest implements Mensagem {
    private int timestamp;
    private int pid;

    public MensagemRequest(int pid, int timestamp) {
        this.timestamp = timestamp;
        this.pid = pid;
    }

    public int getTimestamp() {
        return timestamp;
    }

    public int getPid() {
        return pid;
    }

    @Override
    public String toString() {
        return "MensagemRequest{" +
                "timestamp=" + timestamp +
                ", pid=" + pid +
                '}';
    }
}
