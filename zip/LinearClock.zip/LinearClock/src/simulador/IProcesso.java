package simulador;

import simulador.mensagens.Mensagem;

public interface IProcesso {

    void enviarMensagem(Mensagem mensagem);
    int getPid();

    int getProximoTimestamp();
    int getTimestamp();
    void updateClock(int timestamp);
}
