package simulador;

import simulador.mensagens.Mensagem;
import simulador.mensagens.MensagemOk;
import simulador.mensagens.MensagemRequest;

import java.io.*;
import java.net.Socket;
import java.util.Map;

public class ProcessoRemoto extends Thread implements IProcesso  {

    private Socket socket;
    private int pid;
    private Map<Integer, IProcesso> processos;
    private RicartAgrawala ricartAgrawala;

    private OutputStream outputStream;
    private InputStream inputStream;

    public ProcessoRemoto(Socket socket, int pid, Map<Integer, IProcesso> processos, RicartAgrawala ricartAgrawala) {
        this.socket = socket;
        this.pid = pid;
        this.processos = processos;
        this.ricartAgrawala = ricartAgrawala;

        try {
            this.outputStream = socket.getOutputStream();
            this.inputStream = socket.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.start();
    }

    @Override
    public void enviarMensagem(Mensagem mensagem) {
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(mensagem);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getPid() {
        return pid;
    }

    @Override
    public int getProximoTimestamp() {
        return 0;
    }

    @Override
    public int getTimestamp() {
        return 0;
    }

    @Override
    public void updateClock(int timestamp) {

    }

    @Override
    public void run(){
        escutarMensagens();
    }


    private void tratarMensagem(Object mensagem){
        if(mensagem instanceof MensagemRequest){
            ricartAgrawala.receive((MensagemRequest) mensagem);
        } else if(mensagem instanceof MensagemOk){
            ricartAgrawala.receive((MensagemOk) mensagem);
        }
    }

    private void escutarMensagens() {
        while (true){
            try {
                ObjectInputStream  objectInputStream  = new ObjectInputStream(inputStream);
                Object object = objectInputStream.readObject();
                tratarMensagem(object);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
