package simulador;

import simulador.mensagens.Mensagem;
import simulador.mensagens.MensagemOk;
import simulador.mensagens.MensagemRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class RicartAgrawala {

    Map<Integer, IProcesso> processos;
    int localPid;
    EscutarLog escutarLog;
    List<Integer> pendentes;
    boolean querCS;
    int totalOkEsperados;
    boolean naCS;

    public RicartAgrawala(int localPid, Map<Integer, IProcesso> processos) {
        this.processos = processos;
        this.localPid = localPid;
        this.pendentes = new ArrayList<>();
        querCS = false;
        totalOkEsperados = 0;
    }

    private IProcesso getProcessoLocal(){
        return processos.get(localPid);
    }

    public void setEscutarLog(EscutarLog escutarLog) {
        this.escutarLog = escutarLog;
    }

    public void request(){
        if(!querCS) {
            naCS = false;
            querCS = true;
            totalOkEsperados = processos.size() - 1;
            escutarLog.querCS(totalOkEsperados);

            IProcesso processoLocal = getProcessoLocal();
            MensagemRequest mensagemRequest = new MensagemRequest(processoLocal.getPid(), processoLocal.getProximoTimestamp());
            escutarLog.publicarLog("Requisitando recurso\n" + mensagemRequest.toString() + "\n");

            for (Map.Entry<Integer, IProcesso> entry : processos.entrySet()) {
                IProcesso processo = entry.getValue();
                if (processo.getPid() != processoLocal.getPid()) {
                    processo.enviarMensagem(mensagemRequest);
                }
            }
        }
    }

    public void release(){
        if(naCS) {
            IProcesso processoLocal = getProcessoLocal();
            escutarLog.csLiberada();
            querCS = false;
            naCS = false;
            Mensagem mensagemOK = new MensagemOk(processoLocal.getPid(), processoLocal.getTimestamp());
            for (int pid : pendentes) {
                IProcesso remoto = processos.get(pid);
                remoto.enviarMensagem(mensagemOK);
                escutarLog.publicarLog("Enviado para " + remoto.getPid() + "\n" + mensagemOK.toString() + "\n");
            }
            pendentes.clear();
            escutarLog.atualizarListaPendete(pendentes);
        }
    }


    public void receive(MensagemRequest mensagem){
        escutarLog.publicarLog("Requisição recebida de:\n" + mensagem.toString()+"\n");

        IProcesso processoLocal = getProcessoLocal();
        int timestampAtual = processoLocal.getTimestamp();
        processoLocal.updateClock(mensagem.getTimestamp());

        if(!querCS || mensagem.getTimestamp() < timestampAtual){
            Mensagem mensagemOk = new MensagemOk(this.localPid, processoLocal.getTimestamp());
            escutarLog.publicarLog("OK enviado pra: \n" + mensagemOk.toString() + "\n");
            processos.get(mensagem.getPid()).enviarMensagem(mensagemOk);
        } else {
            escutarLog.publicarLog("Adicionado pendente: " + mensagem.getPid());
            if(!pendentes.contains(mensagem.getPid())) {
                pendentes.add(mensagem.getPid());
            }
            escutarLog.atualizarListaPendete(pendentes);
        }

    }

    public void receive(MensagemOk mensagem){
        escutarLog.publicarLog("Recebido\n" + mensagem.toString() + "\n");
        IProcesso processoLocal = getProcessoLocal();
        processoLocal.updateClock(mensagem.getTimestamp());
        totalOkEsperados--;
        escutarLog.querCS(totalOkEsperados);

        if(totalOkEsperados == 0){
            escutarLog.naCS();
            naCS = true;
        }
    }

}
