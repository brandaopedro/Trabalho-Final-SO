package simulador;


import java.util.List;

public interface EscutarLog {

    void publicarLog(String mensagem);
    void querCS(int okrestantes);
    void naCS();
    void atualizaClock(int clock);
    void atualizarListaPendete(List<Integer> pendentes);

    void csLiberada();
}
