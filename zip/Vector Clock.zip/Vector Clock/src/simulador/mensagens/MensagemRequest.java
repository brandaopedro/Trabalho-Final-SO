package simulador.mensagens;

import java.util.Map;

public class MensagemRequest implements Mensagem {
    private Map <Integer, Integer> timestamp;
    
    private int pid;

    public MensagemRequest(int pid, Map <Integer, Integer> timestamp) {
        this.timestamp =  timestamp;
        this.pid = pid;
    }

    public Map <Integer, Integer> getTimestamp() {
        return timestamp;
    }

    public int getPid() {
        return pid;
    }

    @Override
    public String toString() {
        return "MensagemRequest{" +
                "timestamp=" + timestamp +
                ", pid=" + pid +
                '}';
    }
}
