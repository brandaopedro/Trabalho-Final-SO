package simulador.mensagens;

import java.util.Map;

public class MensagemOk implements Mensagem {
    int pid;
    Map <Integer, Integer> timestamp;

    public int getPid() {
        return pid;
    }

    public Map <Integer, Integer> getTimestamp() {
        return timestamp;
    }

    public MensagemOk(int pid, Map <Integer, Integer> timestamp) {
        this.pid = pid;
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "MensagemOk{" +
                "pid=" + pid +
                ", timestamp=" + timestamp +
                '}';
    }
}
