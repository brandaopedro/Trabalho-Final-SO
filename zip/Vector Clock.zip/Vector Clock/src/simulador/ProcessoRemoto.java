package simulador;

import simulador.mensagens.Mensagem;
import simulador.mensagens.MensagemOk;
import simulador.mensagens.MensagemRequest;

import java.io.*;
import java.net.Socket;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProcessoRemoto extends Thread implements IProcesso  {

    private Socket socket;
    private int pid;
    private Map<Integer, IProcesso> processos;
    private VectorClock clock;
    private boolean bloqueado;

    private OutputStream outputStream;
    private InputStream inputStream;

    public void setBloqueado(boolean bloqueado) {
        this.bloqueado = bloqueado;
    }
        

    public ProcessoRemoto(Socket socket, int pid, Map<Integer, IProcesso> processos, VectorClock vectorClock) {
        this.socket = socket;
        this.pid = pid;
        this.processos = processos;
        this.clock = vectorClock;

        try {
            this.outputStream = socket.getOutputStream();
            this.inputStream = socket.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.start();
    }

     
    @Override
    public void enviarMensagem(Mensagem mensagem) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(bloqueado){
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ProcessoRemoto.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
                try {
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
                    objectOutputStream.writeObject(mensagem);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();        
    }

    @Override
    public int getPid() {
        return pid;
    }

    @Override
    public void run(){
        escutarMensagens();
    }


    private void tratarMensagem(Object mensagem){
        if(mensagem instanceof MensagemRequest){
            clock.receive((MensagemRequest) mensagem);
        } 
    }

    private void escutarMensagens() {
        while (true){
            try {
                ObjectInputStream  objectInputStream  = new ObjectInputStream(inputStream);
                Object object = objectInputStream.readObject();
                tratarMensagem(object);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public Map<Integer, Integer> getProximoTimestamp() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Map<Integer, Integer> getTimestamp() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateClock(Map<Integer, Integer> timestamp) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
