package simulador;

import java.util.Map;
import simulador.mensagens.Mensagem;

public interface IProcesso {

    void enviarMensagem(Mensagem mensagem);
    int getPid();

    Map <Integer, Integer> getProximoTimestamp();
    Map <Integer, Integer> getTimestamp();
    void updateClock(Map <Integer, Integer> timestamp);
    void setBloqueado(boolean bloqueado);

    
    
}
