package simulador;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String args[]){
        int nProcessos = args.length > 0 ? Integer.parseInt(args[0]) : 3;
        List<MaquinaVirtual> maquinas = MaquinaVirtual.criarMaquinas(nProcessos, "localhost");

        for(MaquinaVirtual maquina : maquinas){
            maquina.iniciar();
        }

        for(MaquinaVirtual maquina : maquinas){
            maquina.iniciarConexoes();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
