/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulador;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author alan
 */
public class MapUtils {
    
    
    public static Map<Integer, Integer> clonarMap(Map<Integer, Integer> map){
        Map<Integer, Integer> clone = new HashMap<>();
        
        for(Map.Entry<Integer, Integer> entry : map.entrySet()){
            clone.put(entry.getKey(), entry.getValue());
        }
        
        return clone;
        
    }
    
}
