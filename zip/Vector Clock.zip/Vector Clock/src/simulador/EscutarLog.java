package simulador;


import java.util.List;
import java.util.Map;
import simulador.mensagens.MensagemRequest;

public interface EscutarLog {

    void publicarLog(String mensagem);
    void atualizaClock(Map <Integer, Integer> clock);
    void atulizarLsitaMensans (List <MensagemRequest> pendentes,List <MensagemRequest> entregues);
}
