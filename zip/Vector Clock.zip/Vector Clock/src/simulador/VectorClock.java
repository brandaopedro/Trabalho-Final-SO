package simulador;

import simulador.mensagens.Mensagem;
import simulador.mensagens.MensagemOk;
import simulador.mensagens.MensagemRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class VectorClock {

    Map<Integer, IProcesso> processos;
    int localPid;
    EscutarLog escutarLog;
    List<MensagemRequest> msgPendentes;
    List<MensagemRequest> msgEntregues;
 
    public VectorClock(int localPid, Map<Integer, IProcesso> processos) {
        this.processos = processos;
        this.localPid = localPid;
        this.msgPendentes = new ArrayList<>();
        this.msgEntregues = new ArrayList<>();
        
    }

    private IProcesso getProcessoLocal(){
        return processos.get(localPid);
    }

    public void setEscutarLog(EscutarLog escutarLog) {
        this.escutarLog = escutarLog;
    }

    public void request(){
      
            IProcesso processoLocal = getProcessoLocal();
            MensagemRequest mensagemRequest = new MensagemRequest(processoLocal.getPid(), MapUtils.clonarMap(processoLocal.getTimestamp()));
            escutarLog.publicarLog("Enviando Mensagem\n" + mensagemRequest.toString() + "\n");

            for (Map.Entry<Integer, IProcesso> entry : processos.entrySet()) {
                IProcesso processo = entry.getValue();
                if (processo.getPid() != processoLocal.getPid()) {
                    processo.enviarMensagem(mensagemRequest);
                }
            }

            processoLocal.getProximoTimestamp();
    }

     public void receive(MensagemRequest mensagem){
        escutarLog.publicarLog("Requisição recebida de:\n" + mensagem.toString()+"\n");
        msgPendentes.add(0,mensagem);
        msgRecebida();
       
    }
     
     public boolean isEntregarMensagem (MensagemRequest mensagem){
        IProcesso processoLocal = getProcessoLocal();
        Map <Integer, Integer> clocklocal = processoLocal.getTimestamp();
        boolean entregue = true;
        
        for (Map.Entry<Integer, Integer> entry : mensagem.getTimestamp().entrySet()){            
            
            if(!clocklocal.containsKey(entry.getKey())){
                clocklocal.put(entry.getKey(), 0);                
            }
            
            if (clocklocal.get(entry.getKey()) < entry.getValue()){
                entregue = false;
            }            
        }
        
        
        return entregue;         
     }
     
     public void msgRecebida(){
        IProcesso processoLocal = getProcessoLocal();
        
        List <MensagemRequest> remover = new ArrayList<>();
        for (MensagemRequest msg: msgPendentes){
            boolean entregar = isEntregarMensagem(msg);
            if (entregar){
                msgEntregues.add(0,msg);
                remover.add(0,msg);
                msg.getTimestamp().put(msg.getPid(), msg.getTimestamp().get(msg.getPid())+1);
                processoLocal.updateClock(msg.getTimestamp());
            }
          
        }            
        
        msgPendentes.removeAll(remover);
        escutarLog.atulizarLsitaMensans(msgPendentes, msgEntregues);
        
    }

}
