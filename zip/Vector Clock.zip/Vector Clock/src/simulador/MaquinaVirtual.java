package simulador;

import simulador.mensagens.MensagemPid;


import java.awt.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import simulador.ui.ProcessoUI;

public class MaquinaVirtual {

    private int porta;
    private String ip;
    private int pid;
    private ProcessoUI janela;
    private GerenciadorDeConexoes gerenciadorDeConexoes;
    private Map<Integer, IProcesso> processos;
    private List<MaquinaVirtual> maquinaVirtuals;
    private EscutarLog escutarLog;
    private IProcesso processoLocal;
    private VectorClock vectorClock;
    
    

    public IProcesso getProcessoLocal() {
        return processoLocal;
    }
    public List<MaquinaVirtual> getMaquinasVirtuais(){
        return maquinaVirtuals;
    }
    public void setEscutarLog(EscutarLog escutarLog) {
        
        this.escutarLog = escutarLog;
        vectorClock.setEscutarLog(escutarLog);
        gerenciadorDeConexoes.setEscutarLog(escutarLog);
    }

    public MaquinaVirtual(int porta, String ip, List<MaquinaVirtual> maquinaVirtuals) {
        this.porta = porta;
        this.ip = ip;
        this.pid = porta;
        this.maquinaVirtuals = maquinaVirtuals;
        this.processos = new HashMap<>();
        this.vectorClock = new VectorClock(this.pid, processos);
    }

    public VectorClock getVectorClock() {
        return vectorClock;
    }

    public void iniciar(){
        gerenciadorDeConexoes = new GerenciadorDeConexoes(porta, processos, vectorClock);
        janela = new ProcessoUI(null, false, MaquinaVirtual.this);

        new Thread(new Runnable() {
            @Override
            public void run() {
                janela.setSize(new Dimension(400, 500));
                janela.setLocation((MaquinaVirtual.this.getPid()-30000)* 400, 0);
                janela.setVisible(true);
            }
        }).start();

        new Thread(gerenciadorDeConexoes).start();
    }

    public void iniciarConexoes(){
        this.processoLocal = new ProcessoLocal(porta, escutarLog);
        processos.put(porta, processoLocal);
        
        for(MaquinaVirtual maquinaVirtual: maquinaVirtuals){
            if(this.pid != maquinaVirtual.getPid()) {
                this.conectarCom(maquinaVirtual.getIp(), maquinaVirtual.getPorta());
            }
        }
    }
    public void setBloqueados(Map <Integer, Boolean> bloqueados){
        for (Map.Entry<Integer, Boolean> entry:bloqueados.entrySet()){
            processos.get(entry.getKey()).setBloqueado(entry.getValue());}
        
    }
    private void conectarCom(String ip, int porta) {
        int pidRemoto = porta;
        if (!processos.containsKey(pidRemoto)) {
            boolean conexaoEstabelecida = false;
            while(!conexaoEstabelecida) {
                try {
                    Socket socket = new Socket(ip, porta);
                    conexaoEstabelecida = true;
                    escutarLog.publicarLog("C - Processo " + this.pid + " conectado com " + porta);
                    IProcesso processo = new ProcessoRemoto(socket, pidRemoto, processos, vectorClock);
                    processo.enviarMensagem(new MensagemPid(this.pid));

                    processos.put(pidRemoto, processo);
                    
                } catch (Exception e) {
//                    e.printStackTrace();
                }
            }
        }
    }

    public int getPorta() {
        return porta;
    }

    public String getIp() {
        return ip;
    }

    public static List<MaquinaVirtual> criarMaquinas(int quantidade, String ip){
        List<MaquinaVirtual> maquinas = new ArrayList<>();
        for(int i = 0; i< quantidade; i++){
            maquinas.add(new MaquinaVirtual(30000+i, ip, maquinas));
        }
        return maquinas;
    }

    public int getPid() {
        return pid;
    }
}
