package simulador;

import java.util.HashMap;
import java.util.Map;
import simulador.mensagens.Mensagem;

public class ProcessoLocal implements IProcesso {

    private int pid;
    private Map<Integer, Integer> clock;
    private EscutarLog escutarLog;

    public ProcessoLocal(int pid, EscutarLog escutarLog) {
        this.pid = pid;
        this.clock = new HashMap<>();
        this.clock.put(pid, 0);
        this.escutarLog = escutarLog;
    }

    @Override
    public void enviarMensagem(Mensagem mensagem) {

    }

    @Override
    public int getPid() {
        return pid;
    }

    @Override
    public Map<Integer, Integer> getProximoTimestamp() {
        clock.put(pid, clock.get(pid) + 1);
        escutarLog.atualizaClock(clock);
        return clock;
    }

    @Override
    public Map<Integer, Integer> getTimestamp() {
        return clock;
    }

    public void updateClock(Map<Integer, Integer> timestamp) {
        for (Map.Entry<Integer, Integer> entry : timestamp.entrySet()) {
            if (!clock.containsKey(entry.getKey()) || entry.getValue() > clock.get(entry.getKey())) {
                clock.put(entry.getKey(), entry.getValue());
            }
        }
        escutarLog.atualizaClock(clock);

    }

    private int max(int x, int y) {
        return x > y ? x : y;
    }

    @Override
    public void setBloqueado(boolean bloqueado) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
