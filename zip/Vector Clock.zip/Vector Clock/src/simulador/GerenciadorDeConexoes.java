package simulador;

import simulador.mensagens.MensagemPid;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;

public class GerenciadorDeConexoes implements Runnable {

    private int port;
    private ServerSocket socket;
    private Map<Integer, IProcesso> processos;
    private VectorClock vectorClock;

    private EscutarLog escutarLog;

    public void setEscutarLog(EscutarLog escutarLog) {
        this.escutarLog = escutarLog;
    }

    public GerenciadorDeConexoes(int port, Map<Integer, IProcesso> processos, VectorClock ricartAgrawala) {
        this.port = port;
        this.processos = processos;
        this.vectorClock = ricartAgrawala;
    }

    @Override
    public void run() {
        try {
            socket = new ServerSocket(port);
            escutarLog.publicarLog("Escutando na porta: " + port);

            while(true){
                aguardarNovaConexao();
//                escutarMensagens();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void aguardarNovaConexao() throws IOException {
        Socket novoCliente = socket.accept();
        escutarLog.publicarLog("Nova conexão aceita");
        int pid = aguardarPid(novoCliente);
        processos.put(pid, new ProcessoRemoto(novoCliente, pid, processos, vectorClock));
        escutarLog.publicarLog("S - Processo " +this.port +" conectado com " + pid);
    }

    private int aguardarPid(Socket socket) {
        try {
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
            MensagemPid respostaPid = (MensagemPid) objectInputStream.readObject();
            return respostaPid.getPid();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return 0;
    }
}
